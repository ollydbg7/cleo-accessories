We will launch a version in LUA with more functions soon!

Installation:
copy all files and folders to CLEO folder

use:
/acc (the command is configurable in the INI 'prendas.ini')

Suggestion:
You can share your profiles with your friends and make backup copies of your garment profiles and load them with the game open, you just need to copy the file 'garments.ini' and replace it when you want to use it.

Credits:
Fede & Jose
https://discord.com/invite/nCUrj2W
https://www.youtube.com/JoseSampMods/videos